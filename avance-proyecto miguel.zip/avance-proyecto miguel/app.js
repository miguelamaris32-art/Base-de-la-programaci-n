document.addEventListener("DOMContentLoaded", () => {
  let registrosData = [];

  // 1. Lectura y Consumo de Datos desde data.json
  fetch("data.json")
    .then(response => response.json())
    .then(data => {
      registrosData = data.registros;
      renderTabla(registrosData);
    })
    .catch(error => console.error("Error al cargar data.json:", error));

  // Función para renderizar la tabla en el DOM
  function renderTabla(datos) {
    const tbody = document.querySelector("#tabla-datos tbody");
    tbody.innerHTML = "";
    datos.forEach(item => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${item.id}</td>
        <td>${item.concepto}</td>
        <td>$${parseFloat(item.monto).toFixed(2)}</td>
        <td>${item.estado || "Activo"}</td>
      `;
      tbody.appendChild(tr);
    });
  }

  // 2 y 3. Formulario, Inserción y Regla de Negocio / Validación
  const formulario = document.getElementById("formulario");
  const mensajeError = document.getElementById("mensaje-validacion");

  formulario.addEventListener("submit", (e) => {
    e.preventDefault();
    mensajeError.textContent = "";

    const concepto = document.getElementById("concepto").value.trim();
    const monto = parseFloat(document.getElementById("monto").value);

    // Validación Lógica/Financiera (Regla de negocio: monto debe ser positivo y concepto no vacío)
    if (concepto === "") {
      mensajeError.textContent = "El concepto no puede estar vacío.";
      return;
    }

    if (isNaN(monto) || monto <= 0) {
      mensajeError.textContent = "Error de Validación: El monto debe ser un valor numérico positivo mayor a 0.";
      return;
    }

    // Insertar nuevo registro
    const nuevoRegistro = {
      id: registrosData.length + 101,
      concepto: concepto,
      monto: monto,
      estado: "Registrado"
    };

    registrosData.push(nuevoRegistro);
    renderTabla(registrosData);
    formulario.reset();
  });
});